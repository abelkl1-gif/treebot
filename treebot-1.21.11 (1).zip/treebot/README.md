# TreeBot (Fabric, Minecraft 1.21.11)

Press **G** in-game: your character walks to the nearest tree, chops it, picks up
the drops and replants a sapling. Press **G** again to stop. Rebind in Options > Controls.

## Build on a phone (no PC)
1. Make a free GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab > **Build TreeBot** > wait for the green check.
3. Open that run, download the **treebot-jar** artifact (a zip), unzip, and you get `treebot-1.0.0.jar`.

## Build on a PC
1. Install JDK 21.
2. Open this folder in IntelliJ IDEA (or run `gradle build`).
   If there is no `gradlew`, copy `gradlew`, `gradlew.bat` and the `gradle/` folder from
   the Fabric template (fabricmc.net/develop/template) or run `gradle wrapper`.
3. `./gradlew build` -> jar is in `build/libs/treebot-1.0.0.jar`.
4. Put the jar plus Fabric API (0.141.x for 1.21.11) in your `mods` folder, Fabric Loader 0.18+.

Dev run: `./gradlew runClient`.

## Tweak
All settings are constants at the top of `TreeBot.java` (scan radius, replanting,
stop-on-damage, natural-trees-only, ...).

## Limits
- Reaches ~5 logs above the ground; tall trunks keep their top.
- Replants one sapling (2x2 trees such as jungle/dark oak/big spruce need four).
- Does not check for a full inventory.
- Stops on any damage, lava, death, or when no trees are in range.
- Client-side automation: many multiplayer servers forbid it. Singleplayer / your own server is fine.
