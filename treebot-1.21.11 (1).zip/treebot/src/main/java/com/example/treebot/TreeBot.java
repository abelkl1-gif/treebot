package com.example.treebot;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Client-side tree-chopping bot.
 *
 * It is a small state machine:
 *   SEARCH  -> pick the nearest tree log (or the next log of the tree we are working on)
 *   MINE    -> walk to the log, aim at it, hold attack (clears leaves/grass in the way)
 *   COLLECT -> walk over dropped logs / saplings / sticks / apples
 *   PLANT   -> put a sapling back where the trunk stood
 *
 * Everything is done by pressing the same keys a player would press, so it behaves
 * like a (very focused) human and uses the normal vanilla mining code.
 */
public final class TreeBot {

    // ===================== Settings (edit and rebuild) =====================
    private static final int SCAN_RADIUS = 24;          // how far to look for trees (blocks)
    private static final int SCAN_UP = 10;
    private static final int SCAN_DOWN = 4;
    private static final double MINE_RANGE = 3.4;       // stay this close (reach is 4.5)
    private static final int MAX_LOG_HEIGHT = 4;        // highest log (above ground) we can reach
    private static final boolean ONLY_NATURAL_TREES = true; // ignore logs with no leaves nearby
    private static final boolean REPLANT = true;
    private static final boolean STOP_ON_DAMAGE = true; // safety: stop if anything hurts you
    private static final float TURN_SPEED = 35f;        // max degrees per tick
    private static final int STUCK_LIMIT = 80;          // ticks without moving before giving up
    private static final int TARGET_TIMEOUT = 400;
    private static final int BLACKLIST_TICKS = 1200;
    private static final int COLLECT_TIMEOUT = 140;
    private static final int PLANT_TIMEOUT = 120;
    // =======================================================================

    private enum State { SEARCH, MINE, COLLECT, PLANT }

    private static boolean enabled;
    private static State state = State.SEARCH;

    private static BlockPos target;      // log we are working on
    private static BlockPos lastMined;   // last log we broke (used to stay on the same tree)
    private static BlockPos plantSpot;   // dirt block under the trunk
    private static int stateTicks;
    private static int stuckTicks;
    private static int blockedTicks;
    private static int searchCooldown;
    private static Vec3 lastPos;
    private static long tickCounter;
    private static final Map<BlockPos, Long> blacklist = new HashMap<>();

    private TreeBot() {}

    // ------------------------------------------------------------------ control

    public static void toggle(Minecraft mc) {
        if (enabled) {
            stop(mc, "TreeBot OFF");
            return;
        }
        if (mc.player == null) return;
        enabled = true;
        target = null;
        lastMined = null;
        plantSpot = null;
        blacklist.clear();
        enter(State.SEARCH);
        say(mc, "TreeBot ON");
    }

    private static void stop(Minecraft mc, String message) {
        enabled = false;
        releaseKeys(mc);
        say(mc, message);
    }

    private static void say(Minecraft mc, String text) {
        if (mc.player != null) {
            mc.player.displayClientMessage(Component.literal(text), true);
        }
    }

    private static void releaseKeys(Minecraft mc) {
        Options o = mc.options;
        o.keyUp.setDown(false);
        o.keyJump.setDown(false);
        o.keySprint.setDown(false);
        o.keyAttack.setDown(false);
    }

    private static void enter(State next) {
        state = next;
        stateTicks = 0;
        stuckTicks = 0;
        blockedTicks = 0;
        searchCooldown = 0;
        lastPos = null;
    }

    // --------------------------------------------------------------------- tick

    public static void tick(Minecraft mc) {
        if (!enabled) return;

        LocalPlayer p = mc.player;
        ClientLevel lvl = mc.level;
        if (p == null || lvl == null || mc.gameMode == null) {
            enabled = false;
            return;
        }

        tickCounter++;
        releaseKeys(mc);                 // start neutral every tick, press what we need below
        if (mc.screen != null) return;   // paused while a menu/chat is open

        if (p.isDeadOrDying() || p.isInLava()) {
            stop(mc, "TreeBot stopped: danger");
            return;
        }
        if (STOP_ON_DAMAGE && p.hurtTime > 0) {
            stop(mc, "TreeBot stopped: you took damage");
            return;
        }

        switch (state) {
            case SEARCH -> doSearch(mc, p, lvl);
            case MINE -> doMine(mc, p, lvl);
            case COLLECT -> doCollect(mc, p, lvl);
            case PLANT -> doPlant(mc, p, lvl);
        }
    }

    // ------------------------------------------------------------------- SEARCH

    private static void doSearch(Minecraft mc, LocalPlayer p, ClientLevel lvl) {
        if (--searchCooldown > 0) return;
        searchCooldown = 10;

        // Stay on the tree we are already chopping if there is more of it.
        if (lastMined != null) {
            BlockPos next = findLog(p, lvl, lastMined, 5, 8, 4);
            if (next != null) {
                startMine(lvl, next);
                return;
            }
            lastMined = null;            // tree finished: pick up the drops
            enter(State.COLLECT);
            return;
        }

        plantSpot = null;
        BlockPos found = findLog(p, lvl, p.blockPosition(), SCAN_RADIUS, SCAN_UP, SCAN_DOWN);
        if (found == null) {
            stop(mc, "TreeBot: no trees in range");
            return;
        }
        startMine(lvl, found);
    }

    private static void startMine(ClientLevel lvl, BlockPos pos) {
        target = pos;
        if (REPLANT && plantSpot == null) {
            plantSpot = findGround(lvl, pos);
        }
        enter(State.MINE);
    }

    // --------------------------------------------------------------------- MINE

    private static void doMine(Minecraft mc, LocalPlayer p, ClientLevel lvl) {
        stateTicks++;

        if (target == null || !lvl.getBlockState(target).is(BlockTags.LOGS)) {
            lastMined = target != null ? target : lastMined;
            target = null;
            enter(State.SEARCH);
            return;
        }
        if (stateTicks > TARGET_TIMEOUT) {
            giveUp();
            return;
        }

        Vec3 eye = p.getEyePosition();
        Vec3 center = target.getCenter();
        double dist = eye.distanceTo(center);
        lookAt(p, center);

        // Whatever is under the crosshair gets mined if it is a log, leaves or a plant.
        // That clears canopy and grass between us and the target automatically.
        BlockState hitState = null;
        double hitDist = 0;
        if (mc.hitResult instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
            BlockState s = lvl.getBlockState(hit.getBlockPos());
            if (isClearable(s)) {
                hitState = s;
                hitDist = eye.distanceTo(hit.getBlockPos().getCenter());
            }
        }

        if (hitState != null && hitDist <= MINE_RANGE + 0.6) {
            selectBestTool(p, hitState);
            mc.options.keyAttack.setDown(true);
        }

        if (dist > MINE_RANGE) {
            walk(mc, p, center, dist > 8 && hitState == null, 1.0);
            trackStuck(p);
            if (stuckTicks >= STUCK_LIMIT) giveUp();
        } else if (hitState == null) {
            // In range, but something we should not break is in the way (terrain, a wall...).
            blockedTicks++;
            walk(mc, p, center, false, 1.0);
            if (blockedTicks > 50) giveUp();
        } else {
            blockedTicks = 0;
            stuckTicks = 0;
        }
    }

    private static void giveUp() {
        if (target != null) {
            blacklist.put(target.immutable(), tickCounter + BLACKLIST_TICKS);
        }
        target = null;
        enter(State.SEARCH);
    }

    // ------------------------------------------------------------------ COLLECT

    private static void doCollect(Minecraft mc, LocalPlayer p, ClientLevel lvl) {
        stateTicks++;

        ItemEntity item = nearestDrop(p, lvl, 12);
        if (item == null || stateTicks > COLLECT_TIMEOUT) {
            afterCollect();
            return;
        }

        Vec3 pos = item.position();
        lookAt(p, pos);
        walk(mc, p, pos, true, 0.3);
        trackStuck(p);
        if (stuckTicks >= STUCK_LIMIT) afterCollect();
    }

    private static void afterCollect() {
        if (REPLANT && plantSpot != null) {
            enter(State.PLANT);
        } else {
            plantSpot = null;
            enter(State.SEARCH);
        }
    }

    private static ItemEntity nearestDrop(LocalPlayer p, ClientLevel lvl, double radius) {
        List<ItemEntity> drops = lvl.getEntitiesOfClass(
                ItemEntity.class, p.getBoundingBox().inflate(radius), e -> isWantedDrop(e.getItem()));
        ItemEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (ItemEntity e : drops) {
            double d = e.distanceToSqr(p);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    private static boolean isWantedDrop(ItemStack s) {
        return s.is(ItemTags.LOGS) || s.is(ItemTags.SAPLINGS) || s.is(Items.STICK) || s.is(Items.APPLE);
    }

    // -------------------------------------------------------------------- PLANT

    private static void doPlant(Minecraft mc, LocalPlayer p, ClientLevel lvl) {
        stateTicks++;
        if (plantSpot == null || stateTicks > PLANT_TIMEOUT) {
            endPlant();
            return;
        }

        BlockState ground = lvl.getBlockState(plantSpot);
        BlockState above = lvl.getBlockState(plantSpot.above());
        if (above.is(BlockTags.SAPLINGS)) {          // planted
            endPlant();
            return;
        }

        int slot = findSaplingSlot(p);
        boolean spotOk = ground.is(BlockTags.DIRT) && (above.isAir() || above.is(BlockTags.REPLACEABLE));
        if (slot < 0 || !spotOk) {
            endPlant();
            return;
        }

        Vec3 face = new Vec3(plantSpot.getX() + 0.5, plantSpot.getY() + 1.0, plantSpot.getZ() + 0.5);
        lookAt(p, face);

        if (p.getEyePosition().distanceTo(face) > 3.5) {
            walk(mc, p, face, false, 1.0);
            trackStuck(p);
            if (stuckTicks >= STUCK_LIMIT) endPlant();
            return;
        }

        p.getInventory().setSelectedSlot(slot);
        if (stateTicks % 4 == 0) {
            mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND,
                    new BlockHitResult(face, Direction.UP, plantSpot, false));
            p.swing(InteractionHand.MAIN_HAND);
        }
    }

    private static void endPlant() {
        plantSpot = null;
        enter(State.SEARCH);
    }

    private static int findSaplingSlot(LocalPlayer p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inv.getItem(i).is(ItemTags.SAPLINGS)) return i;
        }
        return -1;
    }

    // ------------------------------------------------------------- tree finding

    /** Nearest valid log inside a box around {@code center}, or null. */
    private static BlockPos findLog(LocalPlayer p, ClientLevel lvl, BlockPos center,
                                    int radius, int up, int down) {
        Vec3 eye = p.getEyePosition();
        List<BlockPos> logs = new ArrayList<>();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();

        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                for (int y = -down; y <= up; y++) {
                    m.set(center.getX() + x, center.getY() + y, center.getZ() + z);
                    if (lvl.getBlockState(m).is(BlockTags.LOGS)) {
                        logs.add(m.immutable());
                    }
                }
            }
        }
        logs.sort(Comparator.comparingDouble(b -> b.distToCenterSqr(eye.x, eye.y, eye.z)));

        for (BlockPos log : logs) {
            if (isBlacklisted(log)) continue;
            if (!reachableFromGround(lvl, log)) continue;
            if (ONLY_NATURAL_TREES && !hasLeavesNearby(lvl, log)) continue;
            return log;
        }
        return null;
    }

    private static boolean isBlacklisted(BlockPos pos) {
        Long until = blacklist.get(pos);
        if (until == null) return false;
        if (tickCounter > until) {
            blacklist.remove(pos);
            return false;
        }
        return true;
    }

    /** First solid block below {@code from}, skipping air, logs, leaves and replaceable plants. */
    private static BlockPos findGround(ClientLevel lvl, BlockPos from) {
        BlockPos.MutableBlockPos m = from.mutable();
        for (int i = 0; i < 16; i++) {
            m.move(Direction.DOWN);
            BlockState s = lvl.getBlockState(m);
            if (!(s.isAir() || s.is(BlockTags.LOGS) || s.is(BlockTags.LEAVES) || s.is(BlockTags.REPLACEABLE))) {
                return m.immutable();
            }
        }
        return null;
    }

    private static boolean reachableFromGround(ClientLevel lvl, BlockPos log) {
        BlockPos ground = findGround(lvl, log);
        return ground != null && log.getY() - (ground.getY() + 1) <= MAX_LOG_HEIGHT;
    }

    private static boolean hasLeavesNearby(ClientLevel lvl, BlockPos log) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int x = -3; x <= 3; x++) {
            for (int z = -3; z <= 3; z++) {
                for (int y = -2; y <= 4; y++) {
                    m.set(log.getX() + x, log.getY() + y, log.getZ() + z);
                    if (lvl.getBlockState(m).is(BlockTags.LEAVES)) return true;
                }
            }
        }
        return false;
    }

    private static boolean isClearable(BlockState s) {
        if (s.is(BlockTags.SAPLINGS)) return false;
        return s.is(BlockTags.LOGS) || s.is(BlockTags.LEAVES) || s.is(BlockTags.REPLACEABLE);
    }

    // ---------------------------------------------------------------- movement

    private static void walk(Minecraft mc, LocalPlayer p, Vec3 to, boolean sprint, double stopDist) {
        Options o = mc.options;
        double dx = to.x - p.getX();
        double dz = to.z - p.getZ();
        if (dx * dx + dz * dz > stopDist * stopDist) {
            o.keyUp.setDown(true);
            if (sprint) o.keySprint.setDown(true);
        }
        if (p.isInWater() || (p.horizontalCollision && p.onGround())) {
            o.keyJump.setDown(true);
        }
    }

    private static void trackStuck(LocalPlayer p) {
        if (lastPos == null) {
            lastPos = p.position();
            return;
        }
        if (stateTicks % 20 == 0) {
            Vec3 now = p.position();
            if (now.distanceToSqr(lastPos) < 0.25) {
                stuckTicks += 20;
            } else {
                stuckTicks = 0;
            }
            lastPos = now;
        }
    }

    private static void lookAt(LocalPlayer p, Vec3 t) {
        Vec3 eye = p.getEyePosition();
        double dx = t.x - eye.x;
        double dy = t.y - eye.y;
        double dz = t.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        p.setYRot(turn(p.getYRot(), yaw, TURN_SPEED));
        p.setXRot(Mth.clamp(turn(p.getXRot(), pitch, TURN_SPEED), -90f, 90f));
    }

    private static float turn(float current, float wanted, float maxStep) {
        float diff = Mth.wrapDegrees(wanted - current);
        return current + Mth.clamp(diff, -maxStep, maxStep);
    }

    /** Pick the hotbar slot that breaks this block fastest (an axe for logs). */
    private static void selectBestTool(LocalPlayer p, BlockState state) {
        Inventory inv = p.getInventory();
        int best = inv.getSelectedSlot();
        float bestSpeed = inv.getItem(best).getDestroySpeed(state);
        for (int i = 0; i < 9; i++) {
            float speed = inv.getItem(i).getDestroySpeed(state);
            if (speed > bestSpeed + 0.01f) {
                bestSpeed = speed;
                best = i;
            }
        }
        if (best != inv.getSelectedSlot()) {
            inv.setSelectedSlot(best);
        }
    }
}
